Project Loaded with all dependencies and functionalities for the 
testing purpose. The following act as a temporary workspace for testing the components of the game.